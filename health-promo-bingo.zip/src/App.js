import React, { useState, useEffect, useCallback } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken } from 'firebase/auth';
import { getFirestore, doc, setDoc, onSnapshot, collection } from 'firebase/firestore';

// Define the bingo board content
const BINGO_BOARD_CONTENT = [
    [
        { text: "Find a classmate who can name the first major assignment and its due date.", type: "syllabus" },
        { text: "With a partner, identify one key theory/framework mentioned in the syllabus.", type: "syllabus" },
        { text: "Using an AI tool, draft a 3-point ethical guideline for using AI in qualitative health research. Discuss with your partner its strengths and weaknesses.", type: "ai" },
        { text: "Discuss with a partner: What is the lowest percentage you can score on an assignment without failing the course?", type: "syllabus" },
        { text: "Find a classmate who can explain the policy on late submissions.", type: "syllabus" },
        { text: "With a partner, find where the syllabus addresses accessibility accommodations.", type: "equity" }
    ],
    [
        { text: "Prompt an AI tool to generate a social media campaign slogan for a public health issue (e.g., vaccine uptake). With your partner, critically evaluate its effectiveness, cultural sensitivity, and potential for misinformation.", type: "ai" },
        { text: "Identify with a partner one specific type of participation expected in this course.", type: "syllabus" },
        { text: "Discuss with a partner: What is the policy for citing sources using APA style in this course?", type: "integrity" },
        { text: "Find a classmate who can tell you the name of one required course reading.", type: "syllabus" },
        { text: "With a partner, locate the section on academic integrity in the syllabus.", type: "integrity" },
        { text: "Ask an AI tool to explain the 'precautionary principle' in health promotion. Discuss with your partner how this principle might apply to the responsible use of AI in public health interventions.", type: "ai" }
    ],
    [
        { text: "Find a classmate who can identify a key topic related to Indigenous content in the course.", type: "equity" },
        { text: "With a partner, discuss what percentage of your final grade is allocated to participation.", type: "syllabus" },
        { text: "FREE SPACE!", type: "free" },
        { text: "With a partner, find the total number of assignments in the course.", type: "syllabus" },
        { text: "Discuss with a partner: What is the best way to communicate with the instructor outside of class?", type: "syllabus" },
        { text: "Find a classmate who can explain the grading breakdown for the final project.", type: "syllabus" }
    ],
    [
        { text: "If our course was a Netflix series, what would its title be and why? (Discuss with a partner).", type: "fun" },
        { text: "With a partner, identify one way the course promotes equity and inclusion.", type: "equity" },
        { text: "With a partner, use an AI tool to identify three emerging health promotion technologies (beyond AI itself). Discuss how AI could intersect with one of these technologies.", type: "ai" },
        { text: "Find a classmate who can tell you the date of the last assignment due.", type: "syllabus" },
        { text: "Discuss with a partner: What is the policy regarding group work and collaboration?", type: "syllabus" },
        { text: "Find a classmate who can name a health promotion theme present in a popular movie or TV show (e.g., 'Contagion', 'House', 'Grey's Anatomy').", type: "fun" }
    ],
    [
        { text: "Discuss with a partner: Which fictional character from pop culture would be the best (or worst!) health promoter and why?", type: "fun" },
        { text: "With a partner, identify one resource available for academic support (e.g., writing center).", type: "syllabus" },
        { text: "Discuss with a partner: How does the syllabus address potential conflicts of interest or ethical considerations?", type: "integrity" },
        { text: "If a health promotion concept could be a meme, what would it be? (Discuss with a partner).", type: "fun" },
        { text: "Find a classmate who can tell you the policy on academic dishonesty.", type: "integrity" },
        { text: "With a partner, identify one key learning outcome for the course.", type: "syllabus" }
    ],
    [
        { text: "Discuss with a partner: What is one question you still have about the course after reviewing the syllabus?", type: "syllabus" },
        { text: "Find a classmate who can share one 'unhealthy' habit they plan to tackle this semester (and maybe a healthy one they'll adopt!).", type: "fun" },
        { text: "With a partner, use an AI tool to generate a short, creative title for a hypothetical health promotion project. Share your favorite.", type: "ai" },
        { text: "Identify with a partner a section in the syllabus that outlines communication expectations (e.g., response times).", type: "syllabus" },
        { text: "Find a classmate who can explain the importance of cultural safety in health promotion.", type: "equity" },
        { text: "Discuss with a partner: What is one strategy you'll use to ensure you meet all deadlines?", type: "fun" }
    ]
];

// For brevity, this file contains only the board content. Full app logic should be restored here if needed.

const App = () => {
    return (
        <div>
            <h1>Health Promotion Bingo Board</h1>
            <pre>{JSON.stringify(BINGO_BOARD_CONTENT, null, 2)}</pre>
        </div>
    );
};

export default App;
